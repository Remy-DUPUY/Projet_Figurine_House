<?php
class EstAssocie {
    private $id_licence;
    private $id_typeFigurine;

    //Getters
    function getIdLicence():int {
        return $this->id_licence;
    }

    function getIdTypeFigurine():int {
        return $this->id_typeDeFigurine;
    }
}

?>