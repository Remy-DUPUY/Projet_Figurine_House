<?php
include("../view/vueFooter.view.html");
?>