DROP TABLE magasin;
DROP TABLE licence;
DROP TABLE marque;
DROP TABLE typeDeFigurine;
DROP TABLE article;
DROP TABLE est_disponible;
DROP TABLE est_associe;
